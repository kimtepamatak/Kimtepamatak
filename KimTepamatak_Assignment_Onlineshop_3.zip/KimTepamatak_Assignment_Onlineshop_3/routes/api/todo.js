const express = require('express');
const router = express.Router();
const todoController = require('../../controllers/todo');

//Api create todo
router.post('/todo', todoController.createTodo);
//Api upload todo
router.put('/todo', todoController.updateTodo);
//Api delete todo
router.delete('/todo', todoController.deleteTodo);
//Api get todo list
router.get('/todo', todoController.getTodos);
module.exports = router;