exports.createTodo = (rep, res, next) => {
    //create to do and store in database
    console.log('create todo');
};
exports.updateTodo = (rep, res, next) => {
    //update todo
};
exports.deleteTodo = (rep, res, next) => {
    //delete todo
};
exports.getTodos = (rep, res, next) => {
    //get list of todo
};