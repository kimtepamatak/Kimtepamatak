exports.getHomePage = (rep, res, next) => {
    res.render('productDetail', {
        pageTittle: 'Home Page',

    })
}