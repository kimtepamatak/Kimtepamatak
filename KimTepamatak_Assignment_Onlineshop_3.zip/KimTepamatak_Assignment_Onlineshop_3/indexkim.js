const path = require('path');
const express = require('express');
const app = express();
app.set('view engine', 'ejs');
app.set('views, views');
app.use(express.static(path.join(__dirname, 'public'))); //example: /var/www/todo/public
//app.use(express.static(__dirname + '/public'));
const adminRoutes = require('./routes/admin');
const todoRoutes = require('./routes/api/todo');
app.use(adminRoutes);
app.use('/api', todoRoutes);
app.listen(3000);